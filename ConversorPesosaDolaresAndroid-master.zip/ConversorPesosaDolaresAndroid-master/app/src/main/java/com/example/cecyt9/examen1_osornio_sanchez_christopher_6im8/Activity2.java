package com.example.cecyt9.examen1_osornio_sanchez_christopher_6im8;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    TextView resultado;
    String dollars, minombre, correo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        resultado= (TextView) findViewById(R.id.resultadoconver);

        Bundle recibe = new Bundle();
        recibe = this.getIntent().getExtras();

        dollars = recibe.getString("dolares");
        minombre="Christopher Osornio Sánchez";

        resultado.setText(minombre+",\n Resultado: "+dollars+" dólares \n" );
    }

    public void onClickEnviar(View sendmail){

        correo="eoropezag@ipn.mx";

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Examen primer parcial");
        intent.putExtra(Intent.EXTRA_TEXT,  resultado.getText().toString()+"Profe si me salió :O ");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { correo} );
        startActivity(intent);
    }
}
