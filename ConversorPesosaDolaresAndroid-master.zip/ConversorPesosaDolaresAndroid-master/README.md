# ConversorPesosaDolaresAndroid

Examen primer parcial

Un conversor simple de pesos a dólares en Android
Envía el resulatdo final al profesor @emmanuel789
